# Flower Bloom — Website Toko Bunga Responsif

Website e-commerce front-end untuk toko bunga, dibuat menggunakan HTML, CSS, dan JavaScript biasa sehingga mudah dipelajari dan diedit di Visual Studio Code.

## Cara menjalankan
1. Ekstrak `Flower-Bloom-Responsive.zip`.
2. Buka folder `flower_bloom_responsive` di Visual Studio Code.
3. Buka `index.html` di browser. Cara yang disarankan: pasang ekstensi **Live Server** di VS Code, klik kanan `index.html`, lalu pilih **Open with Live Server**.
4. Pastikan perangkat terhubung ke internet untuk memuat font dan foto dari Unsplash.

## Struktur folder
- `index.html` — struktur halaman.
- `style.css` — desain, warna, layout, dan aturan responsif.
- `script.js` — katalog, pencarian, kategori, favorit, keranjang, promo, dan checkout WhatsApp.

## Sebelum dipakai berjualan
Buka `script.js`, lalu ganti nilai `STORE_WHATSAPP` dengan nomor WhatsApp toko kamu. Contoh format Indonesia: `6281234567890` (gunakan kode negara 62, tanpa tanda +, spasi, atau angka 0 di depan).
Nomor di atas hanya contoh.

Kode promo demo: `BLOOM10` (diskon 10%, maksimal Rp30.000).

## Fitur
- Tampilan responsif untuk HP, tablet, laptop, dan komputer.
- Navigasi, kolom pencarian, filter kategori, dan pengurutan harga.
- 8 produk contoh dengan detail produk.
- Favorit dan keranjang belanja tersimpan di browser menggunakan `localStorage`.
- Ubah jumlah item, hapus produk, serta hitung subtotal/diskon/total.
- Form detail pesanan yang merangkum pesanan dan membuka WhatsApp toko.
- Tombol salin kode promo, bagian tentang toko, testimoni, dan form newsletter demo.

## Catatan penting
Ini adalah prototipe front-end. Belum ada database, akun pelanggan, stok otomatis, admin panel, gateway pembayaran, atau penyimpanan pesanan di server. Form newsletter hanya contoh antarmuka. Foto produk menggunakan URL Unsplash dan bisa diganti dengan foto milik toko sendiri.
