const STORE_WHATSAPP = "6281234567890"; // Ganti dengan nomor WhatsApp toko, gunakan kode negara tanpa tanda +.
const products = [
 {id:1,name:"Blush Romance",category:"Buket",price:185000,oldPrice:210000,badge:"BEST SELLER",image:"https://images.unsplash.com/photo-1523438885200-e635ba2c371e?auto=format&fit=crop&w=700&q=85",description:"Buket bernuansa merah muda lembut yang manis untuk ulang tahun, anniversary, atau kejutan kecil penuh cinta."},
 {id:2,name:"Classic Red Roses",category:"Mawar",price:225000,oldPrice:null,badge:"FAVORIT",image:"https://images.unsplash.com/photo-1518895949257-7621c3c786d7?auto=format&fit=crop&w=700&q=85",description:"Mawar merah klasik yang elegan untuk mengungkapkan cinta dan perhatian yang tulus."},
 {id:3,name:"Lily White Dream",category:"Lily",price:195000,oldPrice:null,badge:"FRESH PICK",image:"https://images.unsplash.com/photo-1526047932273-341f2a7631f9?auto=format&fit=crop&w=700&q=85",description:"Rangkaian lily putih dengan tampilan bersih dan anggun, cocok untuk ucapan selamat dan momen istimewa."},
 {id:4,name:"Sunshine Day",category:"Buket",price:165000,oldPrice:180000,badge:"-8%",image:"https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&w=700&q=85",description:"Buket cerah dengan nuansa kuning dan pastel untuk menyebarkan semangat baik kepada orang tersayang."},
 {id:5,name:"Blush Premium",category:"Premium",price:325000,oldPrice:null,badge:"PREMIUM",image:"https://images.unsplash.com/photo-1520763185298-1b434c919d1f?auto=format&fit=crop&w=700&q=85",description:"Rangkaian premium pilihan florist dengan perpaduan warna lembut dan kemasan istimewa."},
 {id:6,name:"Sweet Peony",category:"Buket",price:245000,oldPrice:null,badge:"NEW",image:"https://images.unsplash.com/photo-1563241527-3004b7be0ffd?auto=format&fit=crop&w=700&q=85",description:"Buket bergaya romantis dengan bentuk penuh dan tekstur lembut, pas untuk hadiah yang berkesan."},
 {id:7,name:"Garden Mini Rose",category:"Mawar",price:135000,oldPrice:null,badge:"UNDER 150K",image:"https://images.unsplash.com/photo-1548094967-e25a127d1d3b?auto=format&fit=crop&w=700&q=85",description:"Buket mawar mungil yang sederhana namun tetap istimewa untuk membuat hari seseorang lebih indah."},
 {id:8,name:"Little Green Friend",category:"Tanaman",price:99000,oldPrice:null,badge:"EASY CARE",image:"https://images.unsplash.com/photo-1485955900006-10f4d324d411?auto=format&fit=crop&w=700&q=85",description:"Tanaman hias mungil untuk mempercantik meja kerja atau sudut rumah dengan sentuhan alami."}
];
// If an image URL fails, the browser displays a neutral background instead of breaking the layout.
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const rupiah = n => new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
let cart = JSON.parse(localStorage.getItem("flowerBloomCart") || "[]");
let favorites = JSON.parse(localStorage.getItem("flowerBloomFavorites") || "[]");
let activeCategory = "Semua", favoritesOnly = false, appliedPromo = false, toastTimer;

function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600)}
function saveState(){localStorage.setItem("flowerBloomCart",JSON.stringify(cart));localStorage.setItem("flowerBloomFavorites",JSON.stringify(favorites));updateCartCount()}
function productById(id){return products.find(p=>p.id===Number(id))}
function renderProducts(){
 const query=$("#searchInput").value.trim().toLowerCase();
 let list=products.filter(p=>(activeCategory==="Semua"||p.category===activeCategory)&&(!favoritesOnly||favorites.includes(p.id))&&(`${p.name} ${p.category} ${p.description}`.toLowerCase().includes(query)));
 const sort=$("#sortSelect").value;
 if(sort==="low")list.sort((a,b)=>a.price-b.price);if(sort==="high")list.sort((a,b)=>b.price-a.price);if(sort==="name")list.sort((a,b)=>a.name.localeCompare(b.name));
 $("#productGrid").innerHTML=list.map(p=>`<article class="product-card">
  <div class="product-image-wrap"><img class="product-image" src="${p.image}" alt="${p.name}" loading="lazy" onerror="this.style.opacity='.2';this.alt='Foto produk tidak tersedia'">
  ${p.badge?`<span class="product-badge">${p.badge}</span>`:""}
  <button class="favorite-toggle ${favorites.includes(p.id)?"active":""}" data-favorite="${p.id}" aria-label="${favorites.includes(p.id)?"Hapus dari":"Tambahkan ke"} favorit">${favorites.includes(p.id)?"♥":"♡"}</button>
  <button class="quick-view" data-view="${p.id}">LIHAT DETAIL</button></div>
  <div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3><div class="product-bottom"><div class="price">${rupiah(p.price)}${p.oldPrice?`<span class="old-price">${rupiah(p.oldPrice)}</span>`:""}</div><button class="add-cart" data-add="${p.id}" aria-label="Tambahkan ${p.name} ke keranjang">+</button></div></div>
 </article>`).join("");
 $("#emptyState").classList.toggle("hidden",list.length>0);
}
function updateCartCount(){$("#cartCount").textContent=cart.reduce((sum,item)=>sum+item.qty,0)}
function addToCart(id){const item=cart.find(i=>i.id===Number(id));if(item)item.qty++;else cart.push({id:Number(id),qty:1});saveState();renderCart();toast(`${productById(id).name} ditambahkan ke keranjang`)}
function toggleFavorite(id){id=Number(id);favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];saveState();renderProducts();toast(favorites.includes(id)?"Ditambahkan ke favorit ♡":"Dihapus dari favorit")}
function renderCart(){
 const count=cart.reduce((s,i)=>s+i.qty,0),empty=count===0;
 $("#cartEmpty").classList.toggle("hidden",!empty);$("#cartSummary").classList.toggle("hidden",empty);
 $("#cartItems").innerHTML=cart.map(item=>{const p=productById(item.id);if(!p)return "";return `<div class="cart-item"><img src="${p.image}" alt="${p.name}"><div><h3>${p.name}</h3><div class="item-price">${rupiah(p.price)}</div><div class="quantity-control"><button data-qty="${p.id}" data-delta="-1" aria-label="Kurangi jumlah">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-delta="1" aria-label="Tambah jumlah">+</button></div></div><button class="remove-item" data-remove="${p.id}" aria-label="Hapus ${p.name}">×</button></div>`}).join("");
 const subtotal=cart.reduce((s,i)=>s+productById(i.id).price*i.qty,0);
 const discount=appliedPromo?Math.min(Math.round(subtotal*.1),30000):0;
 $("#subtotal").textContent=rupiah(subtotal);$("#discountAmount").textContent="-"+rupiah(discount);$("#discountLine").classList.toggle("hidden",discount===0);$("#total").textContent=rupiah(subtotal-discount);
}
function openCart(){$("#cartDrawer").classList.add("open");$("#overlay").classList.remove("hidden");$("#cartDrawer").setAttribute("aria-hidden","false");document.body.classList.add("no-scroll")}
function closeCart(){$("#cartDrawer").classList.remove("open");$("#overlay").classList.add("hidden");$("#cartDrawer").setAttribute("aria-hidden","true");document.body.classList.remove("no-scroll")}
function openProduct(id){const p=productById(id);if(!p)return;$("#modalContent").innerHTML=`<div class="modal-product-layout"><img src="${p.image}" alt="${p.name}"><div><span class="eyebrow">${p.category.toUpperCase()} · FLOWER BLOOM</span><h2>${p.name}</h2><p>${p.description}</p><div class="price">${rupiah(p.price)} ${p.oldPrice?`<span class="old-price">${rupiah(p.oldPrice)}</span>`:""}</div><button class="btn btn-primary" data-add="${p.id}">Tambahkan ke Keranjang <span>+</span></button></div></div>`;$("#productModal").showModal()}
function closeProduct(){$("#productModal").close()}
function startCheckout(){if(!cart.length){toast("Keranjang masih kosong");return}closeCart();$("#checkoutModal").showModal()}
function sendOrder(event){
 event.preventDefault();const data=new FormData(event.currentTarget);
 const subtotal=cart.reduce((s,i)=>s+productById(i.id).price*i.qty,0),discount=appliedPromo?Math.min(Math.round(subtotal*.1),30000):0;
 const lines=cart.map(i=>`• ${productById(i.id).name} x${i.qty} — ${rupiah(productById(i.id).price*i.qty)}`).join("\n");
 const message=`Halo Flower Bloom, saya ingin memesan bunga.\n\n${lines}\n\nSubtotal: ${rupiah(subtotal)}\nDiskon: ${rupiah(discount)}\nTotal: ${rupiah(subtotal-discount)}\n\nNama: ${data.get("name")}\nWhatsApp: ${data.get("phone")}\nAlamat: ${data.get("address")}\nTanggal pengiriman: ${data.get("date")}\nPesan kartu: ${data.get("note")||"-"}\n\nMohon konfirmasi ketersediaan dan cara pembayaran.`;
 const number=STORE_WHATSAPP.replace(/\D/g,"");
 if(number==="6281234567890") toast("Ingat: ganti nomor WhatsApp toko di script.js sebelum menerima pesanan.");
 window.open(`https://wa.me/${number}?text=${encodeURIComponent(message)}`,"_blank","noopener");
 $("#checkoutModal").close();
}
$("#productGrid").addEventListener("click",e=>{const add=e.target.closest("[data-add]"),fav=e.target.closest("[data-favorite]"),view=e.target.closest("[data-view]");if(add)addToCart(add.dataset.add);if(fav)toggleFavorite(fav.dataset.favorite);if(view)openProduct(view.dataset.view)});
$("#modalContent").addEventListener("click",e=>{const add=e.target.closest("[data-add]");if(add){addToCart(add.dataset.add);closeProduct();openCart()}});
$("#cartItems").addEventListener("click",e=>{const qty=e.target.closest("[data-qty]"),remove=e.target.closest("[data-remove]");if(qty){const item=cart.find(i=>i.id===Number(qty.dataset.qty));if(item){item.qty+=Number(qty.dataset.delta);if(item.qty<=0)cart=cart.filter(i=>i.id!==item.id)}saveState();renderCart()}if(remove){cart=cart.filter(i=>i.id!==Number(remove.dataset.remove));saveState();renderCart()}});
$("#categoryRow").addEventListener("click",e=>{const btn=e.target.closest("[data-category]");if(!btn)return;activeCategory=btn.dataset.category;favoritesOnly=false;$("#favoritesBtn").classList.remove("active");$$(".category-chip").forEach(b=>b.classList.toggle("active",b===btn));renderProducts()});
$("#searchInput").addEventListener("input",renderProducts);$("#sortSelect").addEventListener("change",renderProducts);
$("#favoritesBtn").addEventListener("click",()=>{favoritesOnly=!favoritesOnly;activeCategory="Semua";$$(".category-chip").forEach(b=>b.classList.toggle("active",b.dataset.category==="Semua"));renderProducts();document.querySelector("#koleksi").scrollIntoView({behavior:"smooth"});toast(favoritesOnly?"Menampilkan produk favorit":"Menampilkan semua produk")});
$("#openCartBtn").addEventListener("click",()=>{renderCart();openCart()});$("#closeCartBtn").addEventListener("click",closeCart);$("#overlay").addEventListener("click",closeCart);$("#continueShopping").addEventListener("click",closeCart);$("#checkoutBtn").addEventListener("click",startCheckout);
$("#applyPromo").addEventListener("click",()=>{const code=$("#promoInput").value.trim().toUpperCase();if(code==="BLOOM10"){appliedPromo=true;$("#promoMessage").textContent="Kode berhasil! Diskon 10% (maks. Rp30.000).";renderCart()}else{appliedPromo=false;$("#promoMessage").textContent="Kode promo tidak valid.";$("#promoMessage").style.color="#b94b62";renderCart()}});
$("#copyCoupon").addEventListener("click",async()=>{try{await navigator.clipboard.writeText("BLOOM10");toast("Kode BLOOM10 berhasil disalin")}catch{ $("#promoInput").value="BLOOM10";toast("Kode BLOOM10 siap digunakan di keranjang")}});
$("#checkoutForm").addEventListener("submit",sendOrder);$("#closeModal").addEventListener("click",closeProduct);$("#closeCheckout").addEventListener("click",()=>$("#checkoutModal").close());
$("#productModal").addEventListener("click",e=>{if(e.target===$("#productModal"))closeProduct()});
$("#showAllBtn").addEventListener("click",()=>{activeCategory="Semua";favoritesOnly=false;$("#searchInput").value="";$$(".category-chip").forEach(b=>b.classList.toggle("active",b.dataset.category==="Semua"));renderProducts();toast("Semua koleksi ditampilkan")});
$("#menuToggle").addEventListener("click",()=>{const open=$("#mainNav").classList.toggle("open");$("#menuToggle").setAttribute("aria-expanded",String(open));$("#menuToggle").textContent=open?"×":"☰"});
$$(".main-nav a").forEach(a=>a.addEventListener("click",()=>{$("#mainNav").classList.remove("open");$("#menuToggle").setAttribute("aria-expanded","false");$("#menuToggle").textContent="☰"}));
$("#newsletterForm").addEventListener("submit",e=>{e.preventDefault();toast("Terima kasih! Fitur newsletter demo belum terhubung ke layanan email.");e.currentTarget.reset()});
$("#footerWhatsapp").addEventListener("click",e=>{e.preventDefault();window.open(`https://wa.me/${STORE_WHATSAPP.replace(/\D/g,"")}`,"_blank","noopener")});
$("#year").textContent=new Date().getFullYear();
renderProducts();renderCart();updateCartCount();
// Set the minimum delivery date to today.
$("#checkoutForm").elements.date.min=new Date().toISOString().slice(0,10);
